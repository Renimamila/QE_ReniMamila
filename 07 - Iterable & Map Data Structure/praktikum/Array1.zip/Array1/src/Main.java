

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
public class Main {

    public static void main(String[] args){
        Collection<String> collection = new ArrayList<>();

        collection.add("kazuya");
        collection.add("jin");
        collection.add("lee");
        collection.add("feng");
        collection.addAll(List.of("kazuya"));

        for (var value : collection){
            System.out.println(value);
        }

        System.out.println("remove");
        collection.remove("kazuya");

        for (var value : collection){
            System.out.println(value);
        }
    }

}